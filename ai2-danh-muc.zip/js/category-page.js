/*
 * Nối giao diện trang Danh mục với dữ liệu và Product Grid dùng chung.
 * GIAO ƯỚC ĐỀ XUẤT – NEED CONFIRMATION với AI 1:
 *   window.CEE.products                              : mảng sản phẩm
 *   window.CEE.renderProductGrid(container, products): vẽ (thay toàn bộ) grid
 * Nếu AI 1 đặt tên khác, chỉ cần sửa hàm getShared() bên dưới.
 */
(function () {
  'use strict';

  // NEED CONFIRMATION: đơn vị khoảng cách (ví dụ 'km'). Để trống đến khi nhóm chốt.
  var DISTANCE_UNIT = '';

  function getShared() {
    var cee = window.CEE || {};
    return { products: cee.products, render: cee.renderProductGrid };
  }

  function init() {
    var form = document.getElementById('filter-form');
    var search = document.getElementById('search-input');
    var category = document.getElementById('category-select');
    var distance = document.getElementById('distance-input');
    var status = document.getElementById('result-status');
    var grid = document.getElementById('product-grid');
    var shared = getShared();

    document.getElementById('distance-label').textContent = DISTANCE_UNIT
      ? 'Khoảng cách tối đa (' + DISTANCE_UNIT + ')'
      : 'Khoảng cách tối đa (chưa chốt đơn vị)';

    form.addEventListener('submit', function (e) { e.preventDefault(); });

    if (!Array.isArray(shared.products) || typeof shared.render !== 'function') {
      status.textContent = 'Chưa tích hợp dữ liệu hoặc Product Grid dùng chung.';
      [search, category, distance].forEach(function (el) { el.disabled = true; });
      return;
    }

    window.CEE.filter.getCategories(shared.products).forEach(function (name) {
      category.add(new Option(name, name));
    });

    function update() {
      var result = window.CEE.filter.filterProducts(shared.products, {
        keyword: search.value,
        category: category.value,
        maxDistance: distance.value
      });
      shared.render(grid, result);
      status.textContent = result.length
        ? 'Tìm thấy ' + result.length + ' sản phẩm.'
        : 'Không có sản phẩm phù hợp.';
    }

    search.addEventListener('input', update);
    category.addEventListener('change', update);
    distance.addEventListener('input', update);
    update();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
