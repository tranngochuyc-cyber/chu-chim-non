// Test trình duyệt. Dữ liệu và renderer bên dưới là GIẢ, không phải Product Grid của AI 1.
const { chromium } = require('playwright');
const assert = require('node:assert');
const url = require('url').pathToFileURL(require('path').join(__dirname, '../category.html')).href;

(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const open = async (stub) => {
    const page = await browser.newPage({ viewport: { width: 375, height: 700 } });
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => m.type() === 'error' && errors.push(m.text()));
    if (stub) await page.addInitScript(() => {
      window.CEE = {
        products: [
          { title: 'Bàn gỗ', category: 'A', distance: 2 },
          { title: 'Đèn học', category: 'B', distance: 5 },
          { title: 'Ghế', category: 'A', distance: 10 }
        ],
        renderProductGrid: (el, list) => { el.textContent = list.map(p => p.title).join('|'); }
      };
    });
    await page.goto(url);
    return page;
  };

  let page = await open(false);
  assert.match(await page.textContent('#result-status'), /Chưa tích hợp/);
  assert.ok(await page.isDisabled('#search-input'));
  console.log('PASS trạng thái chưa tích hợp');

  page = await open(true);
  const grid = () => page.textContent('#product-grid');
  assert.strictEqual(await grid(), 'Bàn gỗ|Đèn học|Ghế');
  assert.deepStrictEqual(await page.$$eval('#category-select option', o => o.map(x => x.value)), ['', 'A', 'B']);
  console.log('PASS hiển thị ban đầu và danh mục từ dữ liệu');
  await page.selectOption('#category-select', 'A');
  assert.strictEqual(await grid(), 'Bàn gỗ|Ghế');
  await page.fill('#distance-input', '5');
  assert.strictEqual(await grid(), 'Bàn gỗ');
  await page.fill('#search-input', 'ghe');
  assert.strictEqual(await grid(), '');
  assert.match(await page.textContent('#result-status'), /Không có/);
  await page.fill('#distance-input', '');
  assert.strictEqual(await grid(), 'Ghế');
  console.log('PASS kết hợp lọc, cập nhật kết quả, trạng thái rỗng');
  await page.press('#search-input', 'Enter');
  assert.strictEqual(await page.inputValue('#search-input'), 'ghe');
  console.log('PASS Enter không tải lại trang');
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  console.log('PASS không cuộn ngang ở 375px');
  await page.screenshot({ path: process.argv[2] });
  assert.deepStrictEqual(errors, []);
  console.log('PASS không có lỗi console');
  await browser.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
