# AI 2 – Trang Danh mục, tìm kiếm và lọc

## File (tất cả tạo mới, không sửa file của AI 1 / AI 3)
- category.html
- css/category.css (chỉ định dạng khung trang và bộ lọc)
- js/category-filter.js (logic lọc)
- js/category-page.js (nối giao diện)
- tests/filter.test.js, tests/page.test.js (dữ liệu giả, chỉ để test)
- HUONG-DAN-AI2.md

## Giao ước dùng chung (ĐỀ XUẤT – NEED CONFIRMATION với AI 1)

    window.CEE = window.CEE || {};   // dùng dòng này, không gán đè CEE
    window.CEE.products = [ {
      title: string,
      description: string,
      category: string,
      distance: number,              // đơn vị chưa chốt
      // các trường card của AI 1 (ảnh, condition: 'Like new' | 'Good' | 'Fair', ...)
    } ];
    window.CEE.renderProductGrid = function (container, products) { ... };

`renderProductGrid` phải thay toàn bộ nội dung `container` mỗi lần gọi (không nối thêm),
và chịu được mảng rỗng. AI 2 giữ nguyên object sản phẩm, không đổi nhãn.

## Cách tích hợp
1. Trong category.html, thêm CSS của AI 1 tại chú thích "TÍCH HỢP AI 1".
2. Nạp file dữ liệu và file Product Grid của AI 1 trước js/category-filter.js.
3. Nếu tên trường hoặc tên hàm khác, sửa getShared() (js/category-page.js) và
   filterProducts / getCategories (js/category-filter.js).
4. Dữ liệu phải có sẵn khi trang tải. Nếu AI 1 nạp bất đồng bộ thì cần chỉnh init().

## Quy tắc đang áp dụng
- Tìm trong title và description, không phân biệt hoa/thường và dấu; cả chuỗi phải khớp liền nhau.
- Tìm kiếm, danh mục, khoảng cách kết hợp theo AND, cập nhật ngay khi nhập.
- Danh mục lấy từ dữ liệu.
- Khoảng cách: giữ sản phẩm có distance <= giá trị nhập. Ô trống = không lọc.

## NEED CONFIRMATION
1. Tên trường và hàm render của AI 1.
2. Đơn vị khoảng cách (điền DISTANCE_UNIT trong js/category-page.js).
3. Vị trí tham chiếu / cách có được distance. Hiện chỉ đọc số có sẵn, không định vị.
4. Sản phẩm thiếu distance: đang bị ẩn khi lọc khoảng cách.
5. Danh sách danh mục mẫu của nhóm.
6. Cách đặt liên kết điều hướng giữa 3 trang (chưa thêm).

## Kết quả kiểm tra (27/11/2026)
PASS
- 12/12 unit test logic lọc: `node --test tests/filter.test.js`
- Trình duyệt Chromium với dữ liệu và renderer GIẢ: `node tests/page.test.js anh.png`
  (trạng thái chưa tích hợp, hiển thị ban đầu, kết hợp lọc, kết quả rỗng, Enter, 375px, console)

FAIL
- Không có test nào đang lỗi.

BLOCKED (chưa có file của AI 1)
- Hiển thị bằng Product Grid dùng chung.
- Dùng chung dữ liệu thật, hiển thị badges.

NOT RUN
- Firefox, Safari, thiết bị thật, trình đọc màn hình.
- Tích hợp với AI 3.
